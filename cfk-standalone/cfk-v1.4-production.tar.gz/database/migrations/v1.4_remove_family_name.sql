-- v1.4 Migration: Remove family_name for privacy compliance
-- Run this BEFORE deploying v1.4 files

USE a4409d26_509946;

-- Check if family_name column exists
SET @col_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE table_schema = DATABASE()
    AND table_name = 'families'
    AND column_name = 'family_name'
);

-- Drop column if it exists
SET @query = IF(@col_exists > 0,
    'ALTER TABLE families DROP COLUMN family_name;',
    'SELECT "Column family_name does not exist" AS message;'
);

PREPARE stmt FROM @query;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Verify schema
DESCRIBE families;

SELECT 'Migration complete: family_name column removed' AS status;
